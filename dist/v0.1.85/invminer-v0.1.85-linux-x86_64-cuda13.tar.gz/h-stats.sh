#!/usr/bin/env bash
# Sourced by the HiveOS agent. Set caller-scope `khs` and `stats`; never echo or exit.

invminer_hive_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
invminer_config_override=${CUSTOM_CONFIG_FILENAME:-}
invminer_api_override=${CUSTOM_API_PORT:-}
. "$invminer_hive_dir/h-manifest.conf"

invminer_hive_version=${CUSTOM_VERSION:-unknown}
if [[ -x "$invminer_hive_dir/invminer" ]]; then
    invminer_binary_version=$("$invminer_hive_dir/invminer" --version 2>/dev/null \
        | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 | tr -d '\r')
    [[ -n $invminer_binary_version ]] && invminer_hive_version=$invminer_binary_version
fi

invminer_api_port=${invminer_api_override:-${CUSTOM_API_PORT:-4068}}
invminer_algo=${CUSTOM_ALGO:-unknown}
invminer_config=${invminer_config_override:-${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/invminer/invminer.conf}}
if [[ -r $invminer_config ]]; then
    mapfile -d '' -t invminer_config_args <"$invminer_config"
    for ((invminer_i = 0; invminer_i < ${#invminer_config_args[@]}; invminer_i++)); do
        case ${invminer_config_args[invminer_i]} in
            --api-port)
                ((invminer_i + 1 < ${#invminer_config_args[@]})) \
                    && invminer_api_port=${invminer_config_args[invminer_i + 1]}
                ;;
            --api-port=*) invminer_api_port=${invminer_config_args[invminer_i]#*=} ;;
            --coin|-a)
                ((invminer_i + 1 < ${#invminer_config_args[@]})) \
                    && invminer_algo=${invminer_config_args[invminer_i + 1]}
                ;;
            --coin=*) invminer_algo=${invminer_config_args[invminer_i]#*=} ;;
        esac
    done
fi

invminer_response=$(curl -fsS --max-time 3 "http://127.0.0.1:${invminer_api_port}/stats" 2>/dev/null)
if [[ -n $invminer_response ]] && jq -e . >/dev/null 2>&1 <<<"$invminer_response"; then
    stats=$(jq -c --arg fallback "$invminer_hive_version" --arg fallback_algo "$invminer_algo" '
        def hex2dec:
            ascii_downcase | explode |
            map(if . >= 48 and . <= 57 then . - 48
                elif . >= 97 and . <= 102 then . - 87 else 0 end) |
            reduce .[] as $d (0; . * 16 + $d);
        {
            hs: [.gpus[]? | ((.hs // 0) / 1000)],
            hs_units: "khs",
            total_khs: ((.total_hs // 0) / 1000),
            temp: [.gpus[]? | (.temp // 0)],
            fan: [.gpus[]? | (.fan // 0)],
            bus_numbers: [.gpus[]? | ((.pci_bus_id // "00:00.0") | sub("^[0-9a-fA-F]{4}:"; "") | split(":")[0] | hex2dec)],
            ar: [(.shares.accepted // 0), ((.shares.rejected // 0) + (.shares.stale // 0))],
            uptime: (.uptime // 0),
            ver: (.version // $fallback),
            algo: (.algo // $fallback_algo)
        }' <<<"$invminer_response" 2>/dev/null)
    khs=$(jq -r '(.total_hs // 0) / 1000' <<<"$invminer_response" 2>/dev/null)
fi

if [[ -z ${stats:-} || $stats == null ]]; then
    khs=0
    stats=$(jq -cn --arg ver "$invminer_hive_version" --arg algo "$invminer_algo" \
        '{hs:[0],hs_units:"khs",total_khs:0,temp:[0],fan:[0],bus_numbers:[0],ar:[0,0],uptime:0,ver:$ver,algo:$algo}')
fi
[[ -n ${khs:-} ]] || khs=0
