INVMINER 0.1.85

Machine diagnostics:
- `invminer --build-info` publishes the exact error-catalog schema/version/revision/SHA-256.
- `ERROR-CATALOG.json` is the signed-package machine-readable cause and remediation contract.
- `/stats.errors.active` and `/stats.errors.recent_recovered` expose current state. Do not infer
  a specific fault from process exit status or human log text.

INVMINER is a proprietary NVIDIA GPU/CPU miner. This release contains the latest NOID implementation
and the qualified QUAN native kernels in one executable. Always select the coin explicitly:

  ./invminer --coin noid -o stratum+ssl://eu.innovlab.cc:19601 -u wallet.rig
  ./invminer --coin quan -o stratum+ssl://eu2.innovlab.cc:17601 -u YOUR_QUANTUS_ADDRESS.worker

The `-p/--pass` option is optional. When it is omitted, INVminer uses the compatible default `x`.

For NOID, ordered backup pools may be supplied either as one comma-separated value or by repeating
`--pool`:

  ./invminer --coin noid -o stratum+ssl://PRIMARY:PORT,stratum+ssl://BACKUP:PORT -u wallet.rig

The default `--pool-failover-mode primary` mines through one active connection. While a backup is
active, a bounded one-shot connection periodically authenticates to the primary and verifies a job;
it closes immediately and switches only after consecutive successes. Repeated rapid primary
failures raise the return threshold and eventually avoid it until this miner process is restarted.
Use `--pool-failover-mode rotate` to advance only when the current pool fails, without proactive
primary recovery. INVminer never keeps every primary/backup pool connected in the background.

NOID accepts only the approved innovlab.cc and 01pool.com WebPKI TLS boundary. QUAN accepts protocol-compatible TCP/TLS endpoints and defaults to the public Europe TLS endpoint.

The CUDA 12/HiveOS build requires NVIDIA Linux driver 535 or newer for NOID. On Ampere sm_86 GPUs it tries
the reviewed native performance image first. If the driver rejects that image as incompatible,
INVminer automatically loads the embedded CUDA 12.2 native sm_86 compatibility image. No alternate
package, environment variable, or manual CUDA module selection is required.

QUAN automatically selects its qualified SM75, SM86, SM89, or SM120 native image. Its public
default is the Europe TLS endpoint shown above; another compatible endpoint may be supplied with
an explicit TCP/TLS URL. RTX 50-series requires a Blackwell-capable NVIDIA driver.

Process and boot behavior
-------------------------
The executable runs only in the process explicitly launched by the operator. It never installs or
enables a systemd service, cron job, Windows service, Scheduled Task, Startup-folder item, registry
Run key, launchd job, or Docker restart policy. Optional service/container examples require a
separate explicit administrator action. Installing files alone must leave INVminer stopped and
disabled at boot.

TSC/TensorCash is retired in this release. Selecting `--coin tsc` or `--coin tensorcash` exits
before any network, Docker or GPU action; archived TSC code is not a supported product surface.
Pearl is likewise retired from the current commercial registry. Its preserved source defines the
archived Pearl specification, while `--coin pearl` exits before network or GPU startup.

NOID rejects plaintext Stratum/TCP, insecure TLS and operator SPKI pins before CPU/GPU startup. QUAN follows the explicit URL scheme; use TLS unless the pool explicitly requires plaintext.

Run `./invminer --help` for the complete option list. Useful production options include:

  --api-port 4068                 local read-only stats endpoint
  --api-token SECRET              enables authenticated POST /control via X-Api-Token
  --hashrate-report-secs 0        disables pool-specific hashrate notifications
  --status-interval-secs 120      console-only commercial whole-rig/per-GPU status panel
  --no-color                     disables ANSI colors (NO_COLOR and non-TTY also disable them)
  --fee-percent 1                 selected-coin floor; NOID 1%, QUAN 2%; cannot reduce it
  --watchdog-secs 120             GPU hang exit code 4; 0 disables only the user override
  --min-work-rate <G/s>           sustained low-rate exit code 5; 0 disables
  --temp-limit <C>                thermal throttle/warning line; 0 disables
  --temp-stop <C>                 thermal pause with hysteresis; 0 disables
  --power-limit <W>               optional NVIDIA power cap; 0 leaves it unchanged
  --lock-core <MHz>               optional NVIDIA core upper bound; 0 leaves it unchanged
  --locked-core-clock <MHz>       optional fixed NVIDIA core clock; 0 leaves it unchanged
  --lock-mem <MHz>                optional fixed NVIDIA memory clock; 0 leaves it unchanged
  --core-clock-offset <MHz>       optional signed NVIDIA core offset; 0 leaves it unchanged
  --pool-failover-mode <MODE>     primary (default) or rotate
  --pool-give-up-limit <COUNT>    failed startup sessions before advancing; default 3
  --pool-probe-interval-secs <S>  primary probe interval while on backup; default 60
  --pool-probe-successes <COUNT>  base consecutive successes before returning; default 2
  --retune                        re-probe the reviewed per-GPU NOID profile
  --no-tune-cache                 diagnostic probe with no persistent tuning I/O
  --self-test                     native GPU/CPU golden-vector test without a pool
  --benchmark 15                  offline 15-second test

For a reviewed RTX 4090 operating point, the miner can own both settings directly:

  ./invminer --coin noid --devices 0 --power-limit 450 --lock-mem 810 \
    -o stratum+ssl://eu.innovlab.cc:19601 -u <NOID_ADDRESS>.<WORKER>

The fixed-core and core-upper-bound modes are mutually exclusive. Unsupported clocks or missing
driver permission produce a warning and mining continues from the original driver-managed state;
an incomplete rollback stops instead of mining under unknown settings.

The stats API binds only to 127.0.0.1. GET /stats and GET /metrics remain available when no API
token is set; write control is then disabled. Never put wallet passwords or API tokens in logs.
Every 120 seconds INVMINER prints one aligned console status block with pool state, job epoch, total
hashrate, this-round and process-total A/S/R, and each GPU's rate/temperature/fan/power/clocks/state.
Per-GPU `Temp/HW` means current temperature/NVML hardware limit. The separate RIG TOTAL
`Thermal Limit/Stop(C)` values are the configured INVMINER throttle and pause policy; these values
must not be interpreted as the same threshold.
Interactive terminals use semantic colors without bold; NO_COLOR, --no-color, TERM=dumb and non-TTY
output stay plain. ANSI is never written to the optional miner file-log sink. The panel bypasses that
sink entirely. `--status-interval-secs 0` disables it; `--log-file` remains opt-in.

NOID stores a small, bounded, versioned result after a required first-run probe on an unqualified
GPU. A new INVMINER version probes again; unchanged versions reuse the per-GPU UUID entry. For systemd use
`StateDirectory=invminer` and `INVMINER_STATE_DIR=/var/lib/invminer`. For Docker mount a persistent volume
at `/var/lib/invminer`; without a writable volume mining continues but the result cannot persist.
Forced PTX/JIT diagnostics automatically bypass the production tuning cache.

Developer fee
-------------
This release is compiled in explicit `active` Fee mode. The disclosed developer fee is 1% for NOID
and 2% for QUAN, measured as effective mining time. Each GPU receives its own bounded randomized time window, while the user pool
session remains online; a Fee route must finish connection, authorization and obtain a valid job
before the GPU changes work. `--fee-percent` may be raised for controlled testing but cannot reduce
the selected coin's compiled policy. `./invminer --build-info` records
`fee_assets.release_mode=active` and both per-coin rates. Missing or invalid production Fee assets make
the formal build fail instead of silently publishing a different policy.

Integrity
---------
The signing key is identified by the canonical SHA-256 SubjectPublicKeyInfo fingerprint below:

  sha256:5dfba8946575cd2dcc95aea2a384427cd9cf42ef8ac670fc85e775db9128fb20

Obtain that fingerprint independently from:

  https://raw.githubusercontent.com/getrigeos/INVminer-Release/ca300e2a58b2b8f34107cbc6a017ac3f961a2c9b/release-keys/invminer-release-2026-ed25519.spki.sha256

Do not trust the public key, fingerprint or verification script merely because it was downloaded
beside the archive. First compare the independently obtained fingerprint, then verify the archive:

  sha256sum -c SHA256SUMS.txt
  test "$(openssl pkey -pubin -in RELEASE-PUBLIC-KEY.pem -outform DER 2>/dev/null \
    | sha256sum | awk '{print $1}')" = "5dfba8946575cd2dcc95aea2a384427cd9cf42ef8ac670fc85e775db9128fb20"
  openssl dgst -sha256 -verify RELEASE-PUBLIC-KEY.pem \
    -signature invminer-VERSION-linux-x86_64.tar.gz.sig \
    invminer-VERSION-linux-x86_64.tar.gz

The archive includes BUILD-MANIFEST.json, a locked dependency SBOM, third-party license notices,
release-key audit metadata, the current revocation list and EULA.txt. The metadata and revocation
list inside the archive are audit aids, not independent trust anchors. Mining software may trigger
antivirus/EDR policy; obtain the archive only from the official release channel, verify it, and
create a narrow hash/path exception only if you accept the risk. Do not disable endpoint protection
globally.

Exit codes: 0 normal stop, 2 invalid configuration, 3 unrecoverable GPU failure, 4 GPU hang,
5 sustained low hashrate.
