#!/usr/bin/env bash
set -o pipefail

cd "$(dirname "$0")" || { echo "[h-run] cannot enter miner directory" >&2; exit 1; }
invminer_config_override=${CUSTOM_CONFIG_FILENAME:-}
invminer_log_override=${CUSTOM_LOG_BASENAME:-}
. ./h-manifest.conf

binary=./invminer
config=${invminer_config_override:-${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/invminer/invminer.conf}}
log_base=${invminer_log_override:-${CUSTOM_LOG_BASENAME:-/var/log/miner/custom/invminer/invminer}}

[[ -x $binary ]] || { echo "[h-run] invminer binary is missing or not executable" >&2; exit 127; }
[[ -s $config ]] || { echo "[h-run] generated config is missing; re-apply the flight sheet" >&2; exit 1; }

mapfile -d '' -t invminer_args <"$config"
((${#invminer_args[@]} > 0)) || { echo "[h-run] generated config is empty" >&2; exit 1; }

mkdir -p /run/hive "$(dirname "$log_base")" || exit 1
: >/run/hive/MINER_RUN
printf '%s\n' '{"status":"running"}' >/run/hive/miner_status.1
: >"${log_base}.log"

if pgrep -x invminer >/dev/null 2>&1; then
    echo "[h-run] invminer is already running" >&2
    exit 1
fi

echo "[h-run] starting invminer (coin/pool credentials redacted)"
exec "$binary" "${invminer_args[@]}" >>"${log_base}.log" 2>&1
