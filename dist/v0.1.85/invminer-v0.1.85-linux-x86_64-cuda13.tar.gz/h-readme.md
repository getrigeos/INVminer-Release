# INVminer for HiveOS

One archive contains the single `invminer` executable with native NOID and QUAN support. The process
command is always explicit: `invminer --coin noid ...` or `invminer --coin quan ...`. Per-coin
executable names are not part of the product or package.

## Flight sheet

- Miner: Custom → `invminer`
- Installation URL: the canonical `invminer-X.Y.Z.tar.gz` asset for the release
- Coin: Custom
- Hash algorithm: leave blank
- Pool URL: for NOID use an approved full `stratum+ssl://host:port` URL; for QUAN use a compatible full URL such as `stratum+ssl://eu2.innovlab.cc:17601`
  Put ordered primary/backup URLs in the field separated by commas or semicolons.
- Template: `%WAL%.%WORKER_NAME%` or the literal miner username
- Pass: `x`
- Extra config arguments: `--coin noid` for NOID or `--coin quan` for QUAN. Add ordinary
  `invminer` flags, such as `--devices 0,1`, `--api-port 4068`, or optional hardware controls,
  after the coin selection and put one option/value pair per line when needed. Never paste another
  package URL into this field.

The wrapper reads the explicit `--coin` from Extra config and maps the other flight-sheet fields to
`-o/--pool` and `-u/--user`. It also accepts `noid` or `quan` in Hash algorithm for compatibility
with older flight sheets when Extra config has no coin selection. It adds
`-p/--pass` only when Pass is non-empty; otherwise INVminer applies its compatible default.
It never prints the pool username, password, developer-fee identity, or the generated argument
vector. With no explicit device list, the selected coin automatically uses all visible supported
GPUs and keeps their search domains separate.

Multiple pools still use only one active mining connection. The default primary mode performs a
bounded one-shot login/job probe while the backup keeps mining, closes the probe immediately, and
returns only after consecutive successes. Repeated rapid failures progressively delay and finally
quarantine that primary until the miner process is restarted. Put
`--pool-failover-mode rotate` in Extra config arguments to disable proactive return and rotate only
after an active-pool failure. Optional thresholds are `--pool-give-up-limit`,
`--pool-probe-interval-secs`, and `--pool-probe-successes`.

NOID retains the approved innovlab.cc/01pool.com WebPKI TLS boundary. QUAN accepts protocol-compatible TCP/TLS endpoints and defaults to the public WebPKI TLS endpoint. The selected coin validates its own endpoint before GPU startup.

## CUDA compatibility

HiveOS uses the single canonical `invminer-X.Y.Z.tar.gz` package. HiveOS requires the filename to
contain only the miner name and version; do not add tag `v`, platform, architecture, HiveOS, or CUDA
labels. It contains the broad CUDA 12 host-compatibility build. Direct Linux releases may still
provide separate CUDA 12/13 archives.

For NOID, Ampere `sm_86` GPUs, including RTX 30-series cards, use an automatic two-stage loader. INVminer
tries the reviewed native performance image first and automatically loads the embedded CUDA 12.2
native `sm_86` compatibility image if the installed driver rejects the first image. Do not add a
module selector or CUDA package URL to Extra config arguments. NVIDIA Linux driver 535 or newer is
required for the CUDA 12/HiveOS package.

QUAN selects its qualified native SM75, SM86, SM89, or SM120 image automatically. The flight sheet
does not need an architecture flag. Use a driver compatible with the installed GPU and this release;
RTX 50-series requires a Blackwell-capable driver.

## Dashboard data and logs

`h-stats.sh` reads `http://127.0.0.1:4068/stats`, follows an `--api-port` override, and reports
aggregate/per-GPU hashrate in kH/s plus temperatures, fans, PCI buses, accepted/rejected shares,
uptime, version, and algorithm. Miner logs are written to
`/var/log/miner/custom/invminer/invminer.log`.

Installing this archive creates no service and enables no boot-time miner. HiveOS starts it only
after the operator applies a flight sheet.
