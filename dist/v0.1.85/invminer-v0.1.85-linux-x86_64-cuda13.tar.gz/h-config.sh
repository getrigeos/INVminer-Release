#!/usr/bin/env bash
# HiveOS sources this file after wallet.conf and calls miner_ver/miner_config_gen.
# The generated file is NUL-delimited so pool credentials and extra arguments are never eval'd.

invminer_trim() {
    local value=$1
    value=${value#"${value%%[![:space:]]*}"}
    value=${value%"${value##*[![:space:]]}"}
    printf '%s' "$value"
}

miner_ver() {
    local directory version=""
    directory="/hive/miners/custom/${CUSTOM_NAME:-invminer}"
    if [[ -x "$directory/invminer" ]]; then
        version=$("$directory/invminer" --version 2>/dev/null \
            | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 | tr -d '\r')
    fi
    printf '%s\n' "${version:-${CUSTOM_VERSION:-unknown}}"
}

miner_config_gen() {
    local config_file pool_ssl url template worker wallet coin line
    local -a args=() extra=()
    local explicit_coin=0

    [[ -n ${CUSTOM_URL:-} ]] || {
        echo "ERROR: no pool URL set in the HiveOS flight sheet" >&2
        return 1
    }
    [[ -n ${CUSTOM_TEMPLATE:-} ]] || {
        echo "ERROR: no miner username/template set in the HiveOS flight sheet" >&2
        return 1
    }

    config_file=${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/invminer/invminer.conf}
    if declare -f mkfile_from_symlink >/dev/null 2>&1; then
        mkfile_from_symlink "$config_file"
    else
        mkdir -p "$(dirname "$config_file")" || return 1
        : >"$config_file" || return 1
    fi

    # Extra config is tokenized without eval. Put one option/value pair per line when a value
    # contains shell metacharacters; ordinary HiveOS miner options contain no whitespace.
    if [[ -n ${CUSTOM_USER_CONFIG:-} ]]; then
        while IFS= read -r line; do
            line=${line%%#*}
            line=$(invminer_trim "$line")
            [[ -n $line ]] || continue
            local -a tokens=()
            read -r -a tokens <<<"$line"
            extra+=("${tokens[@]}")
        done <<<"$(printf '%s' "$CUSTOM_USER_CONFIG" | tr ';' '\n')"
    fi
    for ((i = 0; i < ${#extra[@]}; i++)); do
        if [[ ${extra[i]} == --coin || ${extra[i]} == --coin=* || ${extra[i]} == -a ]]; then
            explicit_coin=1
            break
        fi
    done

    if ((explicit_coin == 0)); then
        coin=$(invminer_trim "${CUSTOM_ALGO:-}" | tr '[:upper:]' '[:lower:]')
        [[ -n $coin ]] || {
            echo "ERROR: Hash algorithm is required; use noid or quan for this release" >&2
            return 1
        }
        [[ $coin == noid || $coin == quan ]] || {
            echo "ERROR: unsupported Hash algorithm '$coin'; use noid or quan" >&2
            return 1
        }
        args+=(--coin "$coin")
    fi

    # A host:port-only flight sheet defaults to authenticated TLS. Users who deliberately need
    # plaintext must provide an explicit stratum+tcp:// URL instead of relying on an implicit mode.
    pool_ssl=${POOL_SSL:-${CUSTOM_POOL_SSL:-1}}
    while IFS= read -r url; do
        url=$(invminer_trim "$url")
        [[ -n $url ]] || continue
        if [[ $url != *://* ]]; then
            if [[ $pool_ssl == 1 || $pool_ssl == true ]]; then
                url="stratum+ssl://${url}"
            else
                url="stratum+tcp://${url}"
            fi
        fi
        args+=(-o "$url")
    done <<<"$(printf '%s' "$CUSTOM_URL" | tr ',;' '\n')"

    template=$CUSTOM_TEMPLATE
    if [[ $template == *%* ]]; then
        worker=${WORKER_NAME:-${RIG_NAME:-$(hostname -s 2>/dev/null || hostname)}}
        wallet=${WAL:-${EWAL:-${WALLET:-${WALLET_ADDRESS:-}}}}
        template=${template//%WORKER_NAME%/$worker}
        template=${template//%WORKER%/$worker}
        [[ -n $wallet ]] && template=${template//%WAL%/$wallet}
        [[ -n ${EWAL:-} ]] && template=${template//%EWAL%/$EWAL}
        [[ -n ${DWAL:-} ]] && template=${template//%DWAL%/$DWAL}
        [[ -n ${ZWAL:-} ]] && template=${template//%ZWAL%/$ZWAL}
        [[ -n ${EMAIL:-} ]] && template=${template//%EMAIL%/$EMAIL}
        [[ $template != *%* ]] || {
            echo "ERROR: miner username/template contains an unexpanded HiveOS macro" >&2
            return 1
        }
    fi
    args+=(-u "$template")
    # --pass is optional in INVminer. Preserve an explicitly supplied HiveOS password, but let
    # the executable apply its reviewed default when the flight-sheet field is empty.
    [[ -n ${CUSTOM_PASS:-} ]] && args+=(-p "$CUSTOM_PASS")

    # h-stats.sh consumes the same port from this exact argument vector.
    args+=(--api-port "${CUSTOM_API_PORT:-4068}")
    [[ -n ${CUSTOM_API_TOKEN:-} ]] && args+=(--api-token "$CUSTOM_API_TOKEN")
    args+=("${extra[@]}")

    umask 077
    printf '%s\0' "${args[@]}" >"$config_file" || return 1
    chmod 600 "$config_file" || return 1
}

miner_config_gen || return $?
